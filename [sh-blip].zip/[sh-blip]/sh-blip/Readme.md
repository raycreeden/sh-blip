# SherlockCo - Blips

Sistema para poner blips persistente

##  Requisitos
- [QBCore Framework] - qb-menu

## Instalación
1. Colocá la carpeta `sh-blip` en tu carpeta `resources`.
2. Carga el sql en la base de datos
3. Agregá en tu `server.cfg`:
4. Solo qb-core, no me interesa esx. mas trabajo y la mayoria de servers en esx andan mal.
5. agreguen si quieren que sea modo admin o no ya ustedes.

## Adicionales
Scripts por hobbie.