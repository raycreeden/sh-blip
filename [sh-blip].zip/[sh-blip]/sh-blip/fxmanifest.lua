fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'SherlockCo'
description 'Script para blips permanentes'
version '1.0.0'

-- Dependencias (oxmysql y qb-core)
dependencies {
    'qb-core',
    'oxmysql'
}

shared_scripts {
    '@qb-core/shared/locale.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}
