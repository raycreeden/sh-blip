
-- Whitelist system
Config = {}

-- Whitelist por Discord ID
-- Poné acá los IDs largos de Discord como strings
Config.DiscordWhitelist = {
    "309149118109057025", -- Ejemplo
    "987654321098765432"  -- Agregá más si querés
}
