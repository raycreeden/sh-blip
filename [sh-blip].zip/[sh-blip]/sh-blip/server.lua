local QBCore = exports['qb-core']:GetCoreObject()

function IsPlayerWhitelisted(src)
    local identifiers = GetPlayerIdentifiers(src)

    for _, id in ipairs(identifiers) do
        if string.sub(id, 1, 8) == "discord:" then
            local discordID = string.sub(id, 9)
            for _, allowedID in ipairs(Config.DiscordWhitelist) do
                if discordID == allowedID then
                    return true
                end
            end
        end
    end
    return false
end


-- Guardar blip en la base de datos
RegisterNetEvent('sh-blip:saveBlip', function(data)
    local src = source
        if not IsPlayerWhitelisted(src) then
        TriggerClientEvent('QBCore:Notify', src, "No estás autorizado a crear blips.", "error")
        return
    end
    exports.oxmysql:insert('INSERT INTO blips (title, sprite, colour, x, y, z) VALUES (?, ?, ?, ?, ?, ?)', {
        data.title,
        data.id,
        data.colour,
        data.coords.x,
        data.coords.y,
        data.coords.z
    }, function(insertId)
        print(('[sh-blip] Blip guardado con ID %d por jugador %d'):format(insertId, src))
        
        -- Mandar al cliente para que cree el blip con el dbId
        TriggerClientEvent('sh-blip:loadBlips', src, {{
            title = data.title,
            id = data.id,
            colour = data.colour,
            coords = data.coords,
            dbId = insertId
        }})
    end)
end)

-- Enviar blips al cliente al conectarse
RegisterNetEvent('sh-blip:requestBlips', function()
    local src = source
    exports.oxmysql:query('SELECT * FROM blips', {}, function(result)
        local blips = {}
        for _, row in ipairs(result) do
            table.insert(blips, {
                title = row.title,
                id = row.sprite,
                colour = row.colour,
                coords = { x = row.x, y = row.y, z = row.z },
                dbId = row.id
            })
        end
        TriggerClientEvent('sh-blip:loadBlips', src, blips)
    end)
end)

-- Borrar blip por dbId
RegisterNetEvent('sh-blip:removeBlip', function(dbId)
    local src = source
    exports.oxmysql:execute('DELETE FROM blips WHERE id = ?', {dbId}, function(affectedRows)
        if affectedRows > 0 then
            print(('[sh-blip] Blip con ID %d borrado por jugador %d'):format(dbId, src))
            
            -- Enviar lista actualizada a todos
            exports.oxmysql:query('SELECT * FROM blips', {}, function(newResult)
                local blips = {}
                for _, row in ipairs(newResult) do
                    table.insert(blips, {
                        title = row.title,
                        id = row.sprite,
                        colour = row.colour,
                        coords = { x = row.x, y = row.y, z = row.z },
                        dbId = row.id
                    })
                end
                TriggerClientEvent('sh-blip:loadBlips', -1, blips)
            end)
        else
            print("No se borró ningún blip, ID inválido o no encontrado.")
        end
    end)
end)

RegisterNetEvent("sh-blip:getBlipList", function()
    local src = source
        if not IsPlayerWhitelisted(src) then
        TriggerClientEvent('QBCore:Notify', src, "No estás autorizado para esto.", "error")
        return
    end
    exports.oxmysql:query('SELECT * FROM blips', {}, function(result)
        local blips = {}

        for _, row in ipairs(result) do
            table.insert(blips, {
                title = row.title,
                id = row.sprite,
                colour = row.colour,
                coords = { x = row.x, y = row.y, z = row.z },
                dbId = row.id
            })
        end

        TriggerClientEvent("sh-blip:openMenu", src, blips)
    end)
end)
