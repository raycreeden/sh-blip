local QBCore = exports['qb-core']:GetCoreObject()
local createdBlips = {}

RegisterCommand("blip", function(_, args)
    if #args < 3 then
        print("Uso: /blip [nombre] [sprite] [color]")
        return
    end

    local name = args[1]
    local sprite = tonumber(args[2])
    local color = tonumber(args[3])

    local coords = GetEntityCoords(PlayerPedId())
    local data = {
        title = name,
        id = sprite,
        colour = color,
        coords = { x = coords.x, y = coords.y, z = coords.z }
    }

    -- Guardamos solo cuando el server responde con el ID
    TriggerServerEvent('sh-blip:saveBlip', data)
end, false)

function createBlip(info)
    local blip = AddBlipForCoord(info.coords.x, info.coords.y, info.coords.z)
    SetBlipSprite(blip, info.id)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, info.colour)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(info.title)
    EndTextCommandSetBlipName(blip)

    -- Guardamos el objeto y el ID de base de datos
    table.insert(createdBlips, {
        blip = blip,
        dbId = info.dbId
    })
end

RegisterNetEvent('sh-blip:loadBlips', function(blips)
    -- Borrar blips existentes
    for _, b in ipairs(createdBlips) do
        if DoesBlipExist(b.blip) then
            RemoveBlip(b.blip)
        end
    end
    createdBlips = {}

    -- Crear blips desde DB
    for _, info in ipairs(blips) do
        createBlip(info)
    end
end)

RegisterNetEvent("sh-blip:openMenu", function(blips)
    local menu = {
        {
            header = "Blips Guardados",
            isMenuHeader = true
        }
    }

    for _, b in ipairs(blips) do
        table.insert(menu, {
            header = b.title .. " (ID: " .. b.dbId .. ")",
            txt = "Sprite: " .. b.id .. " | Color: " .. b.colour,
            params = {
                event = "sh-blip:openBlipOptions",
                args = b
            }
        })
    end

    table.insert(menu, {
        icon = "fas fa-window-close",
        header = "Cerrar",
        params = { event = "" }
    })

    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent("sh-blip:openBlipOptions", function(blip)
    local menu = {
        {
            header = "Opciones para: " .. blip.title,
            isMenuHeader = true,
        },
        {   
            icon = "fas fa-location-arrow",
            header = "Marcar en el mapa",
            txt = "Poner waypoint en el GPS",
            params = {
                isServer = false,
                event = "sh-blip:markBlip",
                args = blip
            }
        },
        {
            icon = "fas fa-window-close",
            header = "Eliminar",
            txt = "Quitar blip y borrar de la base de datos",
            params = {
                isServer = true,
                event = "sh-blip:removeBlip",
                args = blip.dbId
            }
        },
        {   
            icon = "fas fa-arrow-alt-circle-left",
            header = "Volver",
            params = { event = "sh-blip:openMenu", args = {} }
        }
    }

    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent("sh-blip:markBlip", function(blip)
    SetNewWaypoint(blip.coords.x, blip.coords.y)
end)


CreateThread(function()
    TriggerServerEvent('sh-blip:requestBlips')
end)

RegisterCommand("delblip", function()
    local playerCoords = GetEntityCoords(PlayerPedId())
    local nearestIndex = nil
    local nearestDistance = math.huge

    for i, b in ipairs(createdBlips) do
        local blipCoords = GetBlipCoords(b.blip)
        local dist = #(playerCoords - vector3(blipCoords.x, blipCoords.y, blipCoords.z))
        if dist < nearestDistance then
            nearestDistance = dist
            nearestIndex = i
        end
    end

    if nearestIndex then
        local dbId = createdBlips[nearestIndex].dbId
        RemoveBlip(createdBlips[nearestIndex].blip)
        table.remove(createdBlips, nearestIndex)
        TriggerServerEvent('sh-blip:removeBlip', dbId)
        print("Blip eliminado y borrado de la base de datos.")
    else
        print("No hay blips cerca para eliminar.")
    end
end, false)

local nuiVisible = false

local function toggleBlipUI(show)
    nuiVisible = show
    SetNuiFocus(show, show)
    SendNUIMessage({
        action = show and "openMenu" or "closeMenu",
        blips = createdBlips -- o la tabla que tengas para enviar los blips actuales a la UI
        -- si querés enviar más datos, agregalos acá
    })
end

-- Nuevo comando para abrir/cerrar UI
RegisterCommand("openblip", function()
    toggleBlipUI(not nuiVisible)
end, false)

-- Abrir UI con Numpad 8
CreateThread(function()
    while true do
        Wait(0)
        if IsControlJustReleased(0, 121) then -- 121 es Numpad 8 en FiveM (INPUT_MP_TEXT_CHAT_TEAM)
            toggleBlipUI(not nuiVisible)
        end
    end
end)

RegisterCommand("showb", function()
    TriggerServerEvent("sh-blip:getBlipList")
end, false)


-- Callback para cerrar UI desde JS
RegisterNUICallback("closeMenu", function(data, cb)
    toggleBlipUI(false)
    cb({})
end)
